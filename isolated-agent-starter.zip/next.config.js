/** @type {import('next').NextConfig} */
const nextConfig = {
  // Note: do NOT set output: 'export' — API routes need a server runtime.
};
module.exports = nextConfig;
